package Dominio;

public class MargemLucro extends EntidadeDominio{
    private float margem;

    public float getMargem() {
        return margem;
    }

    public void setMargem(float margem) {
        this.margem = margem;
    }
}
