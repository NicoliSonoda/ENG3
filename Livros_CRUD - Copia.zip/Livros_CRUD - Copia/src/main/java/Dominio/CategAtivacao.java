package Dominio;

public class CategAtivacao extends EntidadeDominio {
    private String categAtivacao;

    public String getCategAtivacao() {
        return categAtivacao;
    }

    public void setCategAtivacao(String categAtivacao) {
        this.categAtivacao = categAtivacao;
    }
}
