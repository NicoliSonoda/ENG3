package Dominio;

public class CategDesativacao extends EntidadeDominio{
    private String categDesativacao;

    public String getCategDesativacao() {
        return categDesativacao;
    }

    public void setCategDesativacao(String categDesativacao) {
        this.categDesativacao = categDesativacao;
    }
}
