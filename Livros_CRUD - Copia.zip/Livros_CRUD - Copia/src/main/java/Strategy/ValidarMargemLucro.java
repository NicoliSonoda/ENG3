package Strategy;

import Dominio.EntidadeDominio;

//Validar margem de lucro - Um livro somente pode ter seu valor alterado se estiver dentro da
// margem de lucro definida pelo critério de grupo de precificação.
public class ValidarMargemLucro implements IStrategy {
    @Override
    public String processsar(EntidadeDominio entidade) {



        return null;
    }

}
