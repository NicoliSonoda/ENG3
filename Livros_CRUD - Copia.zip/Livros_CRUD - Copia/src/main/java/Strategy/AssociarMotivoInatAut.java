package Strategy;

import Dominio.EntidadeDominio;

public class AssociarMotivoInatAut implements IStrategy {

    @Override
    public String processsar(EntidadeDominio entidade) {
        return null;
   }
}
