package Strategy;

import Dominio.EntidadeDominio;

public class AssociarMotivoInat implements IStrategy {

    @Override
    public String processsar(EntidadeDominio entidade) {
        return null;
    }
}
