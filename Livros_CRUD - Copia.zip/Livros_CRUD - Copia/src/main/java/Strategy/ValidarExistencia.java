package Strategy;

import Dominio.EntidadeDominio;
import Dominio.Livro;

public class ValidarExistencia implements IStrategy {

    @Override
    public String processsar(EntidadeDominio entidade) {

        Livro livro = (Livro) entidade;
        StringBuilder sb = new StringBuilder();




        return null;
    }


}
