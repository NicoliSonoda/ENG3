package Strategy;

import Dominio.EntidadeDominio;

public interface IStrategy {
    String processsar (EntidadeDominio entidade);

}
