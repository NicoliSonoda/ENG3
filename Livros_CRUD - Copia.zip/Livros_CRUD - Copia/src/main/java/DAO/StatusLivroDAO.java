package DAO;

import Dominio.EntidadeDominio;

import java.util.List;

public class StatusLivroDAO implements IDAO{

    public void salvar(EntidadeDominio entidade) {;}


    public String alterar(EntidadeDominio entidade) {
        return null;
    }


    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }


    public String excluir(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public Integer consultarUm(EntidadeDominio entidade) {
        return null;
    }
}
